﻿using Gym.Models.Equipment.Contracts;
using Gym.Repositories.Contracts;
using System.Collections.Generic;
using System.Linq;   
namespace Gym.Repositories
{
    public class EquipmentRepository : IRepository<IEquipment>
    {
        private readonly ICollection<IEquipment> models;
        public IReadOnlyCollection<IEquipment> Models => (IReadOnlyCollection<IEquipment>)this.models;

        public EquipmentRepository()
        {
            models = new List<IEquipment>();
        }
        public void Add(IEquipment model)
        {
          models.Add(model);
        }

        public IEquipment FindByType(string type)
        {
           var e = models.FirstOrDefault( x => x.GetType().Name == type);
            return e;
        }

        public bool Remove(IEquipment model)
        {
            
            
            if (this.models.Contains(model))
            {
            this.models.Remove(model);  
                return true;
            }
            return false;   
        }
    }
}
