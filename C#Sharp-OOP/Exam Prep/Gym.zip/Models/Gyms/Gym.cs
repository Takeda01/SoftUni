﻿using Gym.Models.Athletes.Contracts;
using Gym.Models.Equipment.Contracts;
using Gym.Models.Gyms.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gym.Models.Gyms
{
    public abstract class Gym : IGym
    {
        private string name;
        private double equipmentWeight;
        private readonly ICollection<IEquipment> equipments;
        private readonly ICollection<IAthlete> athletes;
        private Gym()
        {
            this.equipments = new List<IEquipment>();
            this.athletes = new List<IAthlete>();
        }
        public Gym(string name, int capacity):this()
        {
            this.Name = name;
            this.Capacity = capacity;


        }
        public string Name
        {
            get { return name; }
            private set
            {

                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("Gym name cannot be null or empty");
                }

                this.name = value;
            }
        }

        public int Capacity { get; set; }

        public double EquipmentWeight
        {
            get { return equipmentWeight; }
            private set
            {
                foreach (var item in equipments)
                {
                    this.equipmentWeight += item.Weight;
                }
                equipmentWeight = value;
            }
        }

        public ICollection<IEquipment> Equipment => this.equipments;

        public ICollection<IAthlete> Athletes => this.athletes;

        public void AddAthlete(IAthlete athlete)
        {
            if (Capacity == athletes.Count)
            {
                throw new InvalidOperationException("Not enough space in the gym");
            }
            else
            {
                athletes.Add(athlete);
            }
        }

        public void AddEquipment(IEquipment equipment)
        {
            equipments.Add(equipment);
        }

        public void Exercise()
        {
            foreach (var athlete in athletes)
            {
                athlete.Exercise();
            }
        }

        public string GymInfo()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"{this.Name} is a {this.GetType().Name}:");
            if (this.athletes.Count < 1)
            {
                sb.AppendLine("Athletes: No athletes");
            }
            else
            {
                sb.AppendLine($"Athletes: {String.Join(", ", athletes.Select(x => x.FullName))}");
            }
            sb.AppendLine($"Equipment total count: {this.equipments.Count}");
            sb.AppendLine($"Equipment total weight: {this.EquipmentWeight:F2} grams");
            return sb.ToString().Trim();
        }

        public bool RemoveAthlete(IAthlete athlete)
        {

            if (this.Athletes.Contains(athlete))
            {
                Athletes.Remove(athlete);

                return true;
            }
            return false;

        }
    }
}
