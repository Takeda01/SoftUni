﻿

namespace Gym.Models.Equipment
{
    public class BoxingGloves : Equipment
    {
        private const double weights = 227;
        private const decimal prize = 120m;
        public BoxingGloves() 
            : base(weights, prize )
        {
          
        }
    }
}
