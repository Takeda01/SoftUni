﻿

namespace Gym.Models.Equipment
{
    public class Kettlebell : Equipment
    {
        private const double weights = 227;
        private const decimal prize = 120m;
        public Kettlebell() : base(weights,prize)
        {
          
        }
    }
}
