﻿
namespace Gym.Core
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Linq;

    using Contracts;
    using Repositories.Contracts;
    using Repositories;
    using Models.Athletes;
    using Models.Athletes.Contracts;
    using Models.Equipment.Contracts;
    using Models.Equipment;
    using Models.Gyms.Contracts;
    using Models.Gyms;
    using Gym.Utilities.Messages;

    public class Controller : IController
    {
        private IRepository<IEquipment> equipmentRepository;
        private ICollection<IGym> gyms;

        public Controller()
        {
            this.equipmentRepository = new EquipmentRepository();
            this.gyms = new List<IGym>();
        }

        public string AddAthlete(string gymName, string athleteType, string athleteName, string motivation, int numberOfMedals)
        {
            if (athleteType == "Boxer")
            {
                IAthlete athlete = new Boxer(athleteName, motivation, numberOfMedals);
                IGym gym = gyms.FirstOrDefault(x => x.Name == gymName);
                if (gym.GetType().Name == "BoxingGym")
                {
                gym.AddAthlete(athlete);
                return String.Format(OutputMessages.EntityAddedToGym, athleteType, gymName);
                }
                return String.Format(OutputMessages.InappropriateGym);
            }
            else if (athleteType == "Weightlifter")
            {
                IAthlete athlete = new Weightlifter(athleteName, motivation, numberOfMedals);
                IGym gym = gyms.FirstOrDefault(x => x.Name == gymName);
                if (gym.GetType().Name == "WeightliftingGym")
                {
                gym.AddAthlete(athlete);
                return String.Format(OutputMessages.EntityAddedToGym, athleteType, gymName);
                }
                return String.Format(OutputMessages.InappropriateGym);

            }
            else
            {
                throw new InvalidOperationException(String.Format(ExceptionMessages.InvalidAthleteType));

            }
        }

        public string AddEquipment(string equipmentType)//done
        {
            if (equipmentType == "BoxingGloves")
            {
                IEquipment equipment = new BoxingGloves();
                equipmentRepository.Add(equipment);
                return String.Format(OutputMessages.SuccessfullyAdded, equipmentType);
            }
            else if (equipmentType == "Kettlebell")
            {
                IEquipment equipment = new Kettlebell();
                equipmentRepository.Add(equipment);
                return String.Format(OutputMessages.SuccessfullyAdded, equipmentType);
            }
            else
            {
                throw new InvalidOperationException(String.Format(ExceptionMessages.InvalidEquipmentType));

            }
        }

        public string AddGym(string gymType, string gymName)//done
        {
            if (gymType == "BoxingGym")
            {
                IGym gym = new BoxingGym(gymName);
                gyms.Add(gym);
                return String.Format(OutputMessages.SuccessfullyAdded, gymType);
            }
            else if (gymType == "WeightliftingGym")
            {
                IGym gym = new WeightliftingGym(gymName);
                gyms.Add(gym);
                return String.Format(OutputMessages.SuccessfullyAdded, gymType);
            }
            else
            {
                throw new InvalidOperationException(String.Format(ExceptionMessages.InvalidGymType));

            }
        }

        public string EquipmentWeight(string gymName)
        {
            IGym gym = gyms.FirstOrDefault(x => x.Name == gymName);
            return String.Format(OutputMessages.EquipmentTotalWeight,gym.Name, gym.EquipmentWeight);
        }

        public string InsertEquipment(string gymName, string equipmentType)
        {
            IEquipment equipment = equipmentRepository.Models.FirstOrDefault(x => x.GetType().Name == equipmentType);
            if (equipment == null)
            {
                throw new InvalidOperationException(String.Format(ExceptionMessages.InexistentEquipment, equipmentType));
            }
            IGym gym = gyms.FirstOrDefault(x => x.Name == gymName);
            gym.AddEquipment(equipment);
            equipmentRepository.Remove(equipment);
            return String.Format(OutputMessages.EntityAddedToGym, equipmentType, gymName);
        }

        public string Report()
        {
            var sb = new StringBuilder();
            foreach (var item in gyms)
            {
                sb.AppendLine(item.GymInfo());
            }
            return sb.ToString().Trim();
        }

        public string TrainAthletes(string gymName) //firstBug
        {
            IGym gym = gyms.FirstOrDefault(x => x.Name == gymName);
            List<IAthlete> list = (List<IAthlete>)gym.Athletes;
            gym.Exercise();
            List<IAthlete> list1 = (List<IAthlete>)gym.Athletes;
            int counter = 0;
            for (int i = 0; i < list.Count; i++)
            {
                if (list1[i].Stamina == list[i].Stamina)
                {
                    counter++;
                }
            }
            return String.Format(OutputMessages.AthleteExercise, counter); 
        }
    }
}
