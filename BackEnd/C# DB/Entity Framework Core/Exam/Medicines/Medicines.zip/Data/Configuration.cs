﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = "Server=DESKTOP-45ELL31\\SQLEXPRESS;Database=Medicines;Integrated Security=True;";
    }
}
